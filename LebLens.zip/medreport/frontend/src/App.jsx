import { Routes, Route, Navigate } from "react-router-dom";
import { Nav, Footer, Protected } from "./components/ui.jsx";
import Landing from "./pages/Landing.jsx";
import { Login, Register } from "./pages/Auth.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Upload from "./pages/Upload.jsx";
import ReportDetail from "./pages/ReportDetail.jsx";
import History from "./pages/History.jsx";
import ModelPerformance from "./pages/ModelPerformance.jsx";
import About from "./pages/About.jsx";

export default function App() {
  return (
    <>
      <Nav />
      <main>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/model" element={<ModelPerformance />} />
          <Route path="/about" element={<About />} />
          <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
          <Route path="/upload" element={<Protected><Upload /></Protected>} />
          <Route path="/reports" element={<Protected><History /></Protected>} />
          <Route path="/reports/:id" element={<Protected><ReportDetail /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}
