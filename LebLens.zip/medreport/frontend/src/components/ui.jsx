import { Fragment, useState } from "react";
import { Link, NavLink, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../auth.jsx";

/* ───────── small building blocks ───────── */
const ICONS = {
  upload: "M12 16V4m0 0L8 8m4-4l4 4M4 16v3a1 1 0 001 1h14a1 1 0 001-1v-3",
  file: "M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5zM14 3v5h5M9 13h6M9 17h4",
  check: "M5 12.5l4.5 4.5L19 7.5",
  alert: "M12 8v5m0 3.5v.01M10.3 3.9L2.5 17.5a2 2 0 001.7 3h15.6a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z",
  shield: "M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3zM9 12l2 2 4-4",
  scan: "M4 8V5a1 1 0 011-1h3M16 4h3a1 1 0 011 1v3M20 16v3a1 1 0 01-1 1h-3M8 20H5a1 1 0 01-1-1v-3M8 12h8",
  chart: "M4 20V10m6 10V4m6 16v-7m4 7H2",
  clock: "M12 7v5l3 2M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
  lock: "M6 11h12v9H6zM8 11V8a4 4 0 118 0v3",
  list: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
  bulb: "M9 18h6m-5 3h4M12 3a6 6 0 00-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0012 3z",
  link: "M4 12h16m0 0l-6-6m6 6l-6 6",
};
export const Icon = ({ name }) => (
  <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d={ICONS[name]} />
  </svg>
);

export const Logo = () => (
  <span className="logo-tile">
    <svg width="22" height="22" viewBox="0 0 26 26" fill="none" aria-hidden="true">
      <circle cx="11" cy="11" r="7.5" stroke="currentColor" strokeWidth="2.4" />
      <path d="M7.5 11h2.2l1.2-2.6 1.8 5.2 1.1-2.6h1.7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M17 17l6 6" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  </span>
);

export function Spinner({ label = "Loading…" }) {
  return <div className="center-load" role="status"><span className="spinner" />{label}</div>;
}

export const Alert = ({ type = "error", children }) =>
  children ? <div className={`alert ${type}`} role={type === "error" ? "alert" : "status"}>{children}</div> : null;

const BADGE = { Low: "low", High: "high", Normal: "normal", "Pending ML Model": "pending", "Not assessed": "na", Analyzed: "normal" };
export const StatusBadge = ({ status }) => <span className={`badge ${BADGE[status] || "na"}`}>{status}</span>;

const fmt = (n) => (Math.abs(n) >= 100 ? Math.round(n) : Math.round(n * 10) / 10);

// The signature gauge: blue = below range, green = in range, red = above range, pin = your value.
export function RangeBar({ value, low, high, status, labels = false, big = false }) {
  if (value == null || (low == null && high == null)) return <span className="muted small">No range</span>;
  let min, max, zl, zh;
  if (low != null && high != null) { const s = (high - low) || 1; min = low - s * 0.6; max = high + s * 0.6; zl = low; zh = high; }
  else if (high != null) { min = 0; max = Math.max(high * 1.6, value * 1.1); zl = 0; zh = high; }
  else { min = Math.min(low * 0.4, value * 0.9); max = Math.max(low * 2, value * 1.1); zl = low; zh = max; }
  const pct = (v) => Math.min(100, Math.max(0, ((v - min) / (max - min)) * 100));
  const a = pct(zl), b = pct(zh), m = pct(value);
  const cls = { Low: "low", High: "high", Normal: "normal" }[status] || "";
  return (
    <div className={`rbar${big ? " big" : ""}`} role="img" aria-label={`Value ${value}, reference ${low ?? "–"} to ${high ?? "–"}`}>
      <div className="track">
        <i className="seg low" style={{ width: `${a}%` }} />
        <i className="seg ok" style={{ width: `${b - a}%` }} />
        <i className="seg high" />
        <span className={`pin ${cls}`} style={{ left: `${m}%` }} />
      </div>
      {labels && (
        <div className="ticks" aria-hidden="true">
          {low != null && <span style={{ left: `${a}%` }}>{fmt(low)}</span>}
          {high != null && <span style={{ left: `${b}%` }}>{fmt(high)}</span>}
        </div>
      )}
    </div>
  );
}

// Ring chart: share of results that are in range / low / high.
export function Donut({ low = 0, normal = 0, high = 0 }) {
  const total = low + normal + high;
  const R = 54, C = 2 * Math.PI * R;
  let acc = 0;
  const segs = [[normal, "var(--normal)"], [low, "var(--low)"], [high, "var(--high)"]];
  return (
    <div className="donut" role="img" aria-label={`${normal} of ${total} results in range`}>
      <svg viewBox="0 0 140 140">
        <circle cx="70" cy="70" r={R} fill="none" stroke="var(--line)" strokeWidth="16" />
        {total > 0 && segs.map(([n, color], i) => {
          if (!n) return null;
          const len = (n / total) * C;
          const el = <circle key={i} cx="70" cy="70" r={R} fill="none" stroke={color} strokeWidth="16" strokeDasharray={`${Math.max(len - 3, 0.5)} ${C}`} strokeDashoffset={-acc} />;
          acc += len;
          return el;
        })}
      </svg>
      <div className="mid"><b>{normal}/{total}</b><span>in range</span></div>
    </div>
  );
}

/* ───────── results ───────── */
const isFlag = (s) => s === "Low" || s === "High";
const initialOpen = (results) => new Set(results.filter((r) => isFlag(r.status)).map((r) => r.id));

// One table of results. Used on its own (dashboard) or inside a category group (report page).
export function ResultsTable({ results, limit, explain = false, open: openProp, onToggle }) {
  const rows = limit ? results.slice(0, limit) : results;
  // flagged results start expanded so the explanation is the first thing you read
  const [own, setOwn] = useState(() => initialOpen(results));
  const open = openProp || own;
  const toggle = onToggle || ((id) => setOwn((o) => { const n = new Set(o); n.has(id) ? n.delete(id) : n.add(id); return n; }));
  return (
    <div className="table-scroll">
      <table>
        <thead><tr><th>Test name</th><th>Result</th><th>Unit</th><th>Reference range</th><th>Position</th><th>Status</th></tr></thead>
        <tbody>
          {rows.map((r) => {
            const ex = explain && r.explanation;
            const isOpen = ex && open.has(r.id);
            const flag = r.status === "Low" ? "flag-low" : r.status === "High" ? "flag-high" : "";
            return (
              <Fragment key={r.id}>
                <tr id={`res-${r.id}`} className={flag}>
                  <td>{r.test_name}{ex && <><br /><button className="exp-btn" aria-expanded={isOpen} onClick={() => toggle(r.id)}>{isOpen ? "Hide explanation" : "What does this mean?"}</button></>}</td>
                  <td className="num">{r.value}</td>
                  <td>{r.unit || <span className="muted">—</span>}</td>
                  <td>{r.reference_range || <span className="muted">—</span>}</td>
                  <td><RangeBar value={r.value_num} low={r.ref_low} high={r.ref_high} status={r.status} /></td>
                  <td><StatusBadge status={r.status} /></td>
                </tr>
                {isOpen && (
                  <tr className="exp-row"><td colSpan={6}><div className="exp-grid">
                    <div>
                      {r.explanation.what && <><h5>What this test measures</h5><p>{r.explanation.what}</p></>}
                    </div>
                    <div>
                      <h5>What your result suggests</h5><p>{r.explanation.meaning}</p>
                      {r.explanation.deviation && <span className={`dev ${r.status.toLowerCase()}`}>{r.explanation.deviation.text}</span>}
                    </div>
                  </div></td></tr>
                )}
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

const GROUP_ORDER = ["Blood count", "Blood sugar", "Cholesterol & fats", "Kidney function", "Liver & proteins",
  "Electrolytes & minerals", "Thyroid", "Vitamins & iron", "Inflammation", "Other tests"];

// Report page, part 1: the big picture (ring + headline + counts).
export function ReportOverview({ results, summary, modelName, children }) {
  const n = (s) => results.filter((r) => r.status === s).length;
  const low = n("Low"), normal = n("Normal"), high = n("High");
  return (
    <section className="card overview" aria-label="Report summary">
      <Donut low={low} normal={normal} high={high} />
      <div>
        <h3>{summary?.headline || `${results.length} results were read from your report.`}</h3>
        <div className="legend">
          <div className="count-pill normal"><b>{normal}</b><span>In range</span></div>
          <div className="count-pill low"><b>{low}</b><span>Below range</span></div>
          <div className="count-pill high"><b>{high}</b><span>Above range</span></div>
        </div>
        {modelName && <p className="model-note">Each result is compared with the range printed in your report by the “{modelName}” model.</p>}
        {children}
      </div>
    </section>
  );
}

// Report page, part 2: flagged results first, then everything grouped by category.
export function ReportResults({ results, summary }) {
  const [open, setOpen] = useState(() => initialOpen(results));
  const toggle = (id) => setOpen((o) => { const s = new Set(o); s.has(id) ? s.delete(id) : s.add(id); return s; });
  const jump = (id) => {
    setOpen((o) => new Set(o).add(id));
    setTimeout(() => document.getElementById(`res-${id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
  };

  const flagged = results.filter((r) => isFlag(r.status));
  const byGroup = {};
  results.forEach((r) => { const g = r.explanation?.group || "Other tests"; (byGroup[g] = byGroup[g] || []).push(r); });
  const groups = GROUP_ORDER.filter((g) => byGroup[g]).concat(Object.keys(byGroup).filter((g) => !GROUP_ORDER.includes(g)));

  return (
    <>
      {flagged.length > 0 && (
        <div className="section">
          <div className="section-title"><h3>Needs your attention</h3><span className="muted small">{flagged.length} outside the printed range</span></div>
          <div className="attn-grid">
            {flagged.map((r) => (
              <article key={r.id} className={`attn ${r.status.toLowerCase()}`}>
                <div className="attn-top"><h4>{r.test_name}</h4><StatusBadge status={r.status} /></div>
                <div className="val">{r.value}{r.unit && <small>{r.unit}</small>}</div>
                <RangeBar value={r.value_num} low={r.ref_low} high={r.ref_high} status={r.status} labels big />
                <div className="ref">{r.reference_range ? `Reference range ${r.reference_range}${r.unit ? " " + r.unit : ""}` : "No reference range printed"}</div>
                {r.explanation?.deviation && <p className="dev-text">{r.explanation.deviation.text}</p>}
                {r.explanation && <button className="exp-btn" onClick={() => jump(r.id)}>Read the explanation</button>}
              </article>
            ))}
          </div>
        </div>
      )}

      <div className="section">
        <div className="section-title">
          <h3>Test-by-test results</h3>
          <span className="muted small">
            {results.length} tests in {groups.length} {groups.length === 1 ? "category" : "categories"}
            {flagged.length > 0 && <> · <button className="exp-btn" onClick={() => setOpen(open.size ? new Set() : initialOpen(results))}>{open.size ? "Collapse all" : "Expand flagged"}</button></>}
          </span>
        </div>
        {groups.map((g) => {
          const rows = byGroup[g];
          const assessed = rows.filter((r) => ["Low", "Normal", "High"].includes(r.status));
          const bad = assessed.filter((r) => isFlag(r.status));
          return (
            <section className="group" key={g} aria-label={g}>
              <div className="group-head">
                <h4>{g}<span className="n">{rows.length} {rows.length === 1 ? "test" : "tests"}</span></h4>
                {assessed.length > 0 && (bad.length
                  ? <span className="gstate flag"><Icon name="alert" />{bad.length} outside range</span>
                  : <span className="gstate ok"><Icon name="check" />All in range</span>)}
              </div>
              <ResultsTable results={rows} explain open={open} onToggle={toggle} />
            </section>
          );
        })}
      </div>
    </>
  );
}

// Report page, part 3: cross-test patterns and what to do next.
export function ReportInsights({ summary }) {
  if (!summary) return null;
  const hasPatterns = summary.patterns.length > 0;
  return (
    <div className="section">
      <div className={`insights${hasPatterns ? "" : " single"}`}>
        {hasPatterns && (
          <div className="insight">
            <h4><span className="ico"><Icon name="link" /></span>Patterns across your results</h4>
            <ul>{summary.patterns.map((p, i) => <li key={i}>{p}</li>)}</ul>
          </div>
        )}
        <div className="insight next">
          <h4><span className="ico"><Icon name="bulb" /></span>What to do with this</h4>
          <ul>{summary.next_steps.map((p, i) => <li key={i}>{p}</li>)}</ul>
        </div>
      </div>
      <p className="fine">{summary.disclaimer}</p>
    </div>
  );
}

/* ───────── layout ───────── */
export function Nav() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const link = ({ isActive }) => (isActive ? "active" : undefined);
  return (
    <header className="nav">
      <div className="wrap">
        <Link to={user ? "/dashboard" : "/"} className="brand"><Logo />LabLens</Link>
        <nav className="nav-links" aria-label="Main">
          {user ? (<>
            <NavLink to="/dashboard" className={link}>Dashboard</NavLink>
            <NavLink to="/upload" className={link}>Upload</NavLink>
            <NavLink to="/reports" className={link}>History</NavLink>
            <NavLink to="/model" className={link}>Model performance</NavLink>
            <NavLink to="/about" className={link}>About</NavLink>
          </>) : (<>
            <NavLink to="/model" className={link}>Model performance</NavLink>
            <NavLink to="/about" className={link}>About</NavLink>
          </>)}
        </nav>
        {user ? (
          <div className="nav-user">
            <span className="who"><span className="avatar" aria-hidden="true">{user.name.trim().charAt(0).toUpperCase()}</span>{user.name}</span>
            <button className="btn ghost sm" onClick={() => { logout(); nav("/"); }}>Log out</button>
          </div>
        ) : (
          <div className="nav-user">
            <Link to="/login" className="btn ghost sm">Log in</Link>
            <Link to="/register" className="btn sm">Create account</Link>
          </div>
        )}
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="footer"><div className="wrap">
      <span className="brand"><Logo />LabLens</span>
      <p>This application is an educational tool and does not provide medical diagnosis or replace a qualified healthcare professional.</p>
    </div></footer>
  );
}

export function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner label="Checking your session…" />;
  return user ? children : <Navigate to="/login" replace />;
}
