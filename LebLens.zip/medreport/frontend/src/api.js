// All data comes from the FastAPI backend (proxied at /api). No dummy data lives in the frontend.
const BASE = "/api";
const TOKEN_KEY = "lablens_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY));

async function request(path, { method = "GET", json, form } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let body;
  if (json) { headers["Content-Type"] = "application/json"; body = JSON.stringify(json); }
  if (form) body = form;
  let res;
  try {
    res = await fetch(BASE + path, { method, headers, body });
  } catch {
    throw new Error("Cannot reach the server. Make sure the backend is running on port 8000.");
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    const err = new Error((data && data.detail) || `Request failed (${res.status})`);
    err.status = res.status;
    if (res.status === 401 && token) window.dispatchEvent(new Event("lablens:unauthorized"));
    throw err;
  }
  return data;
}

export const api = {
  register: (name, email, password) => request("/register", { method: "POST", json: { name, email, password } }),
  login: (email, password) => request("/login", { method: "POST", json: { email, password } }),
  me: () => request("/me"),
  reports: () => request("/reports"),
  report: (id) => request(`/reports/${id}`),
  results: (id) => request(`/reports/${id}/results`),
  deleteReport: (id) => request(`/reports/${id}`, { method: "DELETE" }),
  upload: (file) => { const f = new FormData(); f.append("file", file); return request("/upload-report", { method: "POST", form: f }); },
  modelPerformance: () => request("/model/performance"),
};
