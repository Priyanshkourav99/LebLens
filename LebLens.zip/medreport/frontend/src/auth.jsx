import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, getToken, setToken } from "./api.js";

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());

  const logout = useCallback(() => { setToken(null); setUser(null); }, []);

  useEffect(() => {
    if (!getToken()) return;
    api.me().then(setUser).catch(logout).finally(() => setLoading(false));
  }, [logout]);

  useEffect(() => {
    window.addEventListener("lablens:unauthorized", logout);
    return () => window.removeEventListener("lablens:unauthorized", logout);
  }, [logout]);

  const accept = (data) => { setToken(data.access_token); setUser(data.user); };
  const login = async (email, pw) => accept(await api.login(email, pw));
  const register = async (name, email, pw) => accept(await api.register(name, email, pw));

  return <Ctx.Provider value={{ user, loading, login, register, logout }}>{children}</Ctx.Provider>;
}
