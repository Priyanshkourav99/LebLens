import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../auth.jsx";
import { Alert, Icon, Logo } from "../components/ui.jsx";

function Form({ mode }) {
  const { user, login, register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const isReg = mode === "register";
  if (user) return <Navigate to="/dashboard" replace />;

  const submit = async (e) => {
    e.preventDefault(); setErr("");
    if (isReg && f.name.trim().length < 2) return setErr("Enter your name.");
    if (!f.email.trim() || !f.password) return setErr("Enter your email and password.");
    if (isReg && f.password.length < 6) return setErr("Password must be at least 6 characters.");
    setBusy(true);
    try {
      isReg ? await register(f.name, f.email, f.password) : await login(f.email, f.password);
      nav("/dashboard");
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <div className="wrap page"><div className="auth">
      <aside className="auth-side">
        <span className="brand" style={{ color: "#fff" }}><Logo />LabLens</span>
        <p className="big">Your lab results, laid out clearly.</p>
        <ul>
          <li><Icon name="scan" />Upload a PDF or photo of your report</li>
          <li><Icon name="chart" />See every value against its reference range</li>
          <li><Icon name="lock" />Reports stay private to your account</li>
        </ul>
      </aside>
      <div className="auth-form">
        <h2>{isReg ? "Create your account" : "Log in"}</h2>
        <p className="muted">{isReg ? "Your reports stay private to your account." : "Welcome back."}</p>
        <Alert>{err}</Alert>
        <form onSubmit={submit} noValidate>
          {isReg && <><label htmlFor="name">Full name</label><input id="name" type="text" autoComplete="name" value={f.name} onChange={set("name")} /></>}
          <label htmlFor="email">Email</label><input id="email" type="email" autoComplete="email" value={f.email} onChange={set("email")} />
          <label htmlFor="pw">Password</label><input id="pw" type="password" autoComplete={isReg ? "new-password" : "current-password"} value={f.password} onChange={set("password")} />
          <button className="btn lg" style={{ width: "100%" }} disabled={busy}>{busy ? "Please wait…" : isReg ? "Create account" : "Log in"}</button>
        </form>
        <p className="small muted" style={{ marginTop: 18, marginBottom: 0 }}>
          {isReg ? <>Already registered? <Link to="/login">Log in</Link></> : <>New here? <Link to="/register">Create an account</Link></>}
        </p>
      </div>
    </div></div>
  );
}
export const Login = () => <Form mode="login" />;
export const Register = () => <Form mode="register" />;
