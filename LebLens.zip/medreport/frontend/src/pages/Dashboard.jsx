import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../auth.jsx";
import { Alert, Icon, Spinner, StatusBadge, ResultsTable } from "../components/ui.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  const [reports, setReports] = useState(null);
  const [latest, setLatest] = useState(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const list = await api.reports();
        setReports(list);
        if (list.length) setLatest(await api.report(list[0].id));
      } catch (e) { setErr(e.message); setReports([]); }
    })();
  }, []);

  if (!reports) return <Spinner label="Loading your dashboard…" />;
  const tests = reports.reduce((a, r) => a + r.result_count, 0);
  const flagged = reports.reduce((a, r) => a + r.flagged_count, 0);

  return (
    <div className="wrap page">
      <div className="welcome">
        <div><h2>Hello, {user.name.split(" ")[0]}</h2><p>Your reports and latest analysis</p></div>
        <Link to="/upload" className="btn light lg"><Icon name="upload" />Upload report</Link>
      </div>
      <Alert>{err}</Alert>
      <div className="stats">
        <div className="stat"><div className="ico"><Icon name="file" /></div><div><b>{reports.length}</b><span>Total reports</span></div></div>
        <div className="stat"><div className="ico ok"><Icon name="list" /></div><div><b>{tests}</b><span>Tests extracted</span></div></div>
        <div className="stat"><div className="ico warn"><Icon name="alert" /></div><div><b>{flagged}</b><span>Values outside range (model)</span></div></div>
      </div>

      {reports.length === 0 ? (
        <div className="empty section"><div className="ico-lg"><Icon name="upload" /></div><h3>No reports yet</h3><p>Upload your first lab report to see the extracted results here.</p><Link to="/upload" className="btn">Upload report</Link></div>
      ) : (<>
        <div className="section">
          <div className="section-title">
            <h3>Latest analysis: {latest?.filename}</h3>
            {latest && <Link to={`/reports/${latest.id}`}>Open full report</Link>}
          </div>
          {latest ? <ResultsTable results={latest.results} limit={6} /> : <Spinner />}
          {latest && latest.results.length > 6 && <p className="small muted" style={{ marginTop: 8 }}>Showing 6 of {latest.results.length} tests.</p>}
        </div>
        <div className="section">
          <div className="section-title"><h3>Recent reports</h3><Link to="/reports">View all</Link></div>
          <div className="list-card">
            {reports.slice(0, 5).map((r) => (
              <div className="list-row" key={r.id}>
                <div className="file-cell">
                  <span className="file-ico"><Icon name="file" /></span>
                  <div><Link to={`/reports/${r.id}`}><b>{r.filename}</b></Link><div className="small muted">{new Date(r.created_at + "Z").toLocaleString()} · {r.result_count} tests</div></div>
                </div>
                <StatusBadge status={r.analysis_status} />
              </div>
            ))}
          </div>
        </div>
      </>)}
    </div>
  );
}
