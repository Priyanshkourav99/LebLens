export default function About() {
  return (
    <div className="wrap page" style={{ maxWidth: 860 }}>
      <h2>About this project</h2>
      <p className="muted" style={{ fontSize: "1.08rem", maxWidth: "62ch" }}>LabLens is an academic AI/ML project for analyzing laboratory reports. A user uploads a blood or lab report, the system extracts the printed test names, results, units and reference ranges, and a machine-learning component assesses each result.</p>

      <h3 style={{ marginTop: 32 }}>How it is built</h3>
      <ol className="pipeline">
        <li><b>Read</b><span>PDFs are read with PyMuPDF; images and scans with Tesseract OCR.</span></li>
        <li><b>Parse</b><span>A rule-based parser turns the text into rows. Only values that appear in the report are kept.</span></li>
        <li><b>Assess</b><span>The ML step labels each result Low, Normal or High against the printed range.</span></li>
        <li><b>Store</b><span>Users, reports and results live in SQLite behind a FastAPI backend.</span></li>
      </ol>
      <p style={{ maxWidth: "70ch" }}>The React frontend talks to the FastAPI backend. The ML step is isolated in <code>backend/ml/predict.py</code>, so the model can be replaced without touching the rest of the app.</p>

      <h3 style={{ marginTop: 32 }}>Current model</h3>
      <p style={{ maxWidth: "70ch" }}>The bundled model was trained on a synthetic dataset generated from typical reference ranges. It classifies a result as Low, Normal or High relative to the range in the report. It is a demonstration of the pipeline, not a clinically validated model. See the Model performance page for the exact figures and what they mean.</p>
      <p className="disclaimer">This application is an educational tool and does not provide medical diagnosis or replace a qualified healthcare professional.</p>
    </div>
  );
}
