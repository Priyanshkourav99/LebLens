import { useEffect, useState } from "react";
import { api } from "../api.js";
import { Alert, Icon, Spinner } from "../components/ui.jsx";

const pct = (v) => (v * 100).toFixed(2) + "%";

export default function ModelPerformance() {
  const [m, setM] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api.modelPerformance().then(setM).catch((e) => { setErr(e.message); setM({ trained: false }); }); }, []);
  if (!m) return <Spinner label="Loading model metrics…" />;

  const max = m.trained ? Math.max(...m.confusion_matrix.flat(), 1) : 1;

  return (
    <div className="wrap page">
      <div className="page-head"><div><h2>Model performance</h2><span className="muted">Evaluation results read from the backend</span></div></div>
      <Alert>{err}</Alert>
      {!m.trained ? (
        <div className="empty"><div className="ico-lg"><Icon name="chart" /></div><h3>Model not trained yet</h3><p>Accuracy, precision, recall, F1 score, the confusion matrix and the model comparison will appear here once a model is trained.</p></div>
      ) : (<>
        <Alert type="info">{m.note}</Alert>
        <p className="muted">Selected model: <b style={{ color: "var(--ink)" }}>{m.model_name}</b> · trained {m.trained_at} · {m.train_size} training / {m.test_size} test samples · scores are {m.averaging}-averaged</p>
        <div className="stats">
          {[["Accuracy", m.accuracy], ["Precision", m.precision], ["Recall", m.recall], ["F1 score", m.f1]].map(([k, v]) => (
            <div className="stat" key={k}><div className="ico ok"><Icon name="check" /></div><div><b>{pct(v)}</b><span>{k}</span></div></div>))}
        </div>
        <div className="grid2 section">
          <div>
            <h3>Confusion matrix</h3>
            <div className="table-scroll matrix"><table className="matrix">
              <thead><tr><th>Actual ↓ / Predicted →</th>{m.labels.map((l) => <th key={l}>{l}</th>)}</tr></thead>
              <tbody>{m.confusion_matrix.map((row, i) => (
                <tr key={i}><th>{m.labels[i]}</th>{row.map((v, j) => (
                  <td key={j} className={i === j ? "diag" : ""} style={i === j ? { background: `rgba(27,146,102,${0.12 + 0.3 * (v / max)})` } : undefined}>{v}</td>))}</tr>))}
              </tbody>
            </table></div>
          </div>
          <div>
            <h3>Model comparison</h3>
            <div className="table-scroll"><table style={{ minWidth: 0 }}>
              <thead><tr><th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1</th></tr></thead>
              <tbody>{m.comparison.map((c) => (
                <tr key={c.model} className={c.model === m.model_name ? "cmp-best" : ""}><td>{c.model}{c.model === m.model_name && " ✓"}</td><td>{pct(c.accuracy)}</td><td>{pct(c.precision)}</td><td>{pct(c.recall)}</td><td>{pct(c.f1)}</td></tr>))}
              </tbody>
            </table></div>
          </div>
        </div>
      </>)}
    </div>
  );
}
