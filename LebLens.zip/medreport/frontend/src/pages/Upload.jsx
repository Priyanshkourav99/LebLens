import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { Alert, Icon } from "../components/ui.jsx";

const OK_EXT = [".pdf", ".jpg", ".jpeg", ".png"];
const MAX = 10 * 1024 * 1024;

export default function Upload() {
  const nav = useNavigate();
  const input = useRef();
  const [file, setFile] = useState(null);
  const [over, setOver] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const pick = (f) => {
    setErr("");
    if (!f) return;
    const ext = f.name.slice(f.name.lastIndexOf(".")).toLowerCase();
    if (!OK_EXT.includes(ext)) return setErr("Unsupported file type. Choose a PDF, JPG or PNG file.");
    if (f.size === 0) return setErr("This file is empty.");
    if (f.size > MAX) return setErr("File is too large. The maximum size is 10 MB.");
    setFile(f);
  };

  const submit = async () => {
    setBusy(true); setErr("");
    try {
      const rep = await api.upload(file);
      nav(`/reports/${rep.id}`, { state: { flash: `Report analyzed: ${rep.result_count} tests extracted.` } });
    } catch (e) { setErr(e.message); setBusy(false); }
  };

  return (
    <div className="wrap page">
      <div className="page-head"><div><h2>Upload a report</h2><span className="muted">PDF, JPG or PNG · up to 10 MB</span></div></div>
      <Alert>{err}</Alert>
      <div className="upload-grid">
        <div>
          <div className={`drop ${over ? "over" : ""} ${file ? "has-file" : ""}`} role="button" tabIndex={0}
            onClick={() => input.current.click()} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && input.current.click()}
            onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); pick(e.dataTransfer.files[0]); }}>
            <div className="ico-lg"><Icon name={file ? "file" : "upload"} /></div>
            <strong>{file ? file.name : "Drop your report here, or click to choose a file"}</strong>
            <span className="muted">{file ? `${(file.size / 1024).toFixed(0)} KB · click to choose a different file` : "Blood tests, lipid panels, metabolic panels and similar lab reports"}</span>
            {!file && <div className="chips"><span className="chip">PDF</span><span className="chip">JPG</span><span className="chip">PNG</span></div>}
            <input ref={input} type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" hidden onChange={(e) => pick(e.target.files[0])} />
          </div>
          <div className="upload-actions">
            <button className="btn lg" disabled={!file || busy} onClick={submit}>{busy ? "Analyzing…" : "Upload and analyze"}</button>
            {busy && <><div className="progress" aria-hidden="true"><i /></div><span className="muted small">Reading the report. Scanned files can take a few seconds.</span></>}
          </div>
        </div>
        <aside className="card">
          <h3>What happens next</h3>
          <ol className="side-list">
            <li><div><b>We read the text</b><span>PDFs are read directly; photos and scans use OCR.</span></div></li>
            <li><div><b>We find each test</b><span>Name, result, unit and the printed reference range.</span></div></li>
            <li><div><b>You get a clear layout</b><span>Results grouped by category, with anything out of range first.</span></div></li>
          </ol>
        </aside>
      </div>
    </div>
  );
}
