import { Link } from "react-router-dom";
import { Icon, RangeBar, StatusBadge } from "../components/ui.jsx";
import { useAuth } from "../auth.jsx";

// Illustration only (not user data): shows how a result is presented once a report is analyzed.
const SAMPLE = [
  { n: "Hemoglobin", v: 11.2, u: "g/dL", lo: 13, hi: 17, s: "Low" },
  { n: "Fasting glucose", v: 92, u: "mg/dL", lo: 70, hi: 100, s: "Normal" },
  { n: "Total cholesterol", v: 228, u: "mg/dL", lo: null, hi: 200, s: "High" },
];

export default function Landing() {
  const { user } = useAuth();
  return (
    <>
      <div className="hero-band">
        <div className="wrap hero">
          <div>
            <h1>Read your lab report in under a minute.</h1>
            <p className="lead">Upload a blood or laboratory report as a PDF or photo. LabLens pulls out each test, its result, unit and reference range, and shows where every value sits.</p>
            <div className="cta-row">
              {user
                ? <Link className="btn light lg" to="/upload">Upload a report</Link>
                : <><Link className="btn light lg" to="/register">Create free account</Link><Link className="btn outline-light lg" to="/login">Log in</Link></>}
            </div>
            <ul className="hero-points">
              <li><Icon name="scan" />PDF, JPG and PNG</li>
              <li><Icon name="lock" />Private to your account</li>
              <li><Icon name="shield" />Nothing is guessed</li>
            </ul>
          </div>
          <div className="slip" aria-label="Illustration of an analyzed report">
            <h4>Complete blood &amp; lipid panel</h4>
            <div className="meta">Illustration of the results view, not a real report</div>
            {SAMPLE.map((r) => (
              <div className="slip-row" key={r.n}>
                <div className="slip-top">
                  <span>{r.n} <b>{r.v}</b> <span className="muted small">{r.u}</span></span>
                  <StatusBadge status={r.s} />
                </div>
                <RangeBar value={r.v} low={r.lo} high={r.hi} status={r.s} labels />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="wrap section">
        <div className="features">
          <div className="feature"><div className="ico"><Icon name="scan" /></div><h3>Reads PDFs and photos</h3><p className="muted">Text-based PDFs are read directly. Scanned reports and images go through OCR.</p></div>
          <div className="feature"><div className="ico"><Icon name="shield" /></div><h3>Only what is printed</h3><p className="muted">Test names, values, units and ranges are copied from your report. Nothing is guessed or filled in.</p></div>
          <div className="feature"><div className="ico"><Icon name="lock" /></div><h3>Private to your account</h3><p className="muted">Each report is stored under your login. You can reopen or delete any report at any time.</p></div>
        </div>
      </div>

      <div className="wrap section">
        <h2>How it works</h2>
        <ol className="steps">
          <li><b>Create an account</b><p className="muted small">Register and log in.</p></li>
          <li><b>Upload a report</b><p className="muted small">PDF, JPG or PNG, up to 10 MB.</p></li>
          <li><b>Review extracted values</b><p className="muted small">Check each test against its reference range.</p></li>
          <li><b>Keep your history</b><p className="muted small">Come back to earlier reports from the dashboard.</p></li>
        </ol>
      </div>

      <div style={{ height: 64 }} />
    </>
  );
}
