import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { api } from "../api.js";
import { Alert, Icon, Spinner, ReportOverview, ReportResults, ReportInsights } from "../components/ui.jsx";

export default function ReportDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { state } = useLocation();
  const [rep, setRep] = useState(null);
  const [err, setErr] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.report(id).then(setRep).catch((e) => setErr(e.message)); }, [id]);

  const del = async () => {
    setBusy(true);
    try { await api.deleteReport(id); nav("/reports", { state: { flash: "Report deleted." } }); }
    catch (e) { setErr(e.message); setBusy(false); }
  };

  if (err && !rep) return <div className="wrap page"><Alert>{err}</Alert><Link to="/reports">Back to history</Link></div>;
  if (!rep) return <Spinner label="Loading report…" />;
  const ok = rep.prediction_status === "OK";

  return (
    <div className="wrap page">
      <Alert type="success">{state?.flash}</Alert>
      <Alert>{err}</Alert>

      <header className="report-head">
        <div className="top">
          <div>
            <Link to="/reports" className="back">‹ All reports</Link>
            <h2>{rep.filename}</h2>
            <div className="meta-chips">
              <span className="meta-chip"><Icon name="clock" />Uploaded {new Date(rep.created_at + "Z").toLocaleString()}</span>
              <span className="meta-chip"><Icon name="scan" />Read via {rep.extraction_method === "ocr" ? "OCR" : "PDF text"}</span>
              <span className="meta-chip"><Icon name="list" />{rep.result_count} tests</span>
            </div>
          </div>
          {confirm ? (
            <div className="confirm">
              <span>Delete this report?</span>
              <button className="btn danger sm" disabled={busy} onClick={del}>{busy ? "Deleting…" : "Yes, delete"}</button>
              <button className="btn ghost sm" onClick={() => setConfirm(false)}>Cancel</button>
            </div>
          ) : <button className="btn danger sm" onClick={() => setConfirm(true)}>Delete report</button>}
        </div>
      </header>

      <ReportOverview results={rep.results} summary={rep.summary} modelName={ok ? rep.model_name : null}>
        {!ok && <div style={{ marginTop: 14 }}><Alert type="info">{rep.prediction_status === "MODEL_NOT_CONNECTED" ? "Pending ML Model. The trained ML model is not connected yet." : (rep.prediction_message || "Analysis unavailable.")}</Alert></div>}
      </ReportOverview>

      <ReportResults results={rep.results} summary={rep.summary} />
      <p className="small muted" style={{ marginTop: 14 }}>Values are copied from your report as printed. Please verify them against the original document.</p>

      <ReportInsights summary={rep.summary} />

      {rep.raw_text && <details className="raw section"><summary>Extracted raw text</summary><pre style={{ whiteSpace: "pre-wrap", fontSize: ".85rem", marginBottom: 0 }}>{rep.raw_text}</pre></details>}
      <p className="disclaimer small section">This application is an educational tool and does not provide medical diagnosis or replace a qualified healthcare professional.</p>
    </div>
  );
}
