import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { api } from "../api.js";
import { Alert, Icon, Spinner, StatusBadge } from "../components/ui.jsx";

export default function History() {
  const { state } = useLocation();
  const [reports, setReports] = useState(null);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState(state?.flash || "");
  const [pending, setPending] = useState(null);

  useEffect(() => { api.reports().then(setReports).catch((e) => { setErr(e.message); setReports([]); }); }, []);

  const del = async (id) => {
    setErr(""); setMsg("");
    try { await api.deleteReport(id); setReports((r) => r.filter((x) => x.id !== id)); setMsg("Report deleted."); }
    catch (e) { setErr(e.message); }
    setPending(null);
  };

  if (!reports) return <Spinner label="Loading history…" />;
  return (
    <div className="wrap page">
      <div className="page-head"><div><h2>Report history</h2><span className="muted">{reports.length} saved report{reports.length === 1 ? "" : "s"}</span></div><Link to="/upload" className="btn"><Icon name="upload" />Upload report</Link></div>
      <Alert type="success">{msg}</Alert><Alert>{err}</Alert>
      {reports.length === 0 ? (
        <div className="empty"><div className="ico-lg"><Icon name="file" /></div><h3>No reports yet</h3><p>Reports you upload will be listed here.</p><Link to="/upload" className="btn">Upload report</Link></div>
      ) : (
        <div className="table-scroll"><table>
          <thead><tr><th>Report</th><th>Uploaded</th><th>Tests</th><th>Outside range</th><th>Status</th><th></th></tr></thead>
          <tbody>{reports.map((r) => (
            <tr key={r.id}>
              <td><div className="file-cell"><span className="file-ico"><Icon name="file" /></span><Link to={`/reports/${r.id}`}>{r.filename}</Link></div></td>
              <td>{new Date(r.created_at + "Z").toLocaleString()}</td>
              <td>{r.result_count}</td>
              <td>{r.flagged_count > 0 ? <span className="badge high">{r.flagged_count}</span> : <span className="badge normal">0</span>}</td>
              <td><StatusBadge status={r.analysis_status} /></td>
              <td style={{ whiteSpace: "nowrap", textAlign: "right" }}>
                {pending === r.id ? (<>
                  <button className="btn danger sm" onClick={() => del(r.id)}>Confirm delete</button>{" "}
                  <button className="btn ghost sm" onClick={() => setPending(null)}>Cancel</button></>
                ) : (<>
                  <Link to={`/reports/${r.id}`} className="btn ghost sm">Open</Link>{" "}
                  <button className="btn danger sm" onClick={() => setPending(r.id)}>Delete</button></>)}
              </td>
            </tr>))}
          </tbody>
        </table></div>
      )}
    </div>
  );
}
