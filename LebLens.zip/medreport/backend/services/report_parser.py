"""Rule-based parser: turns raw report text into test / value / unit / reference range rows.
It only returns what is literally present in the text; nothing is inferred or invented."""
import re

NUM = r"\d+(?:[.,]\d+)?"
UNIT = r"(?:/?(?:x\s?)?10[\^*%]?\d+/?[A-Za-zµμ]+|/?[A-Za-zµμ%][A-Za-z0-9µμ%/^.*³]*)"
RANGE = rf"(?:{NUM}\s*(?:-|–|—|to)\s*{NUM}|(?:<=|>=|<|>|≤|≥)\s*{NUM})"
FLAG = r"(?:H|L|HH|LL|High|Low|\*)"

LINE_RE = re.compile(
    rf"^(?P<name>[A-Za-z][A-Za-z0-9 .,()'/%+\-]{{1,70}}?)\s+"
    rf"(?P<value>{NUM})\s*(?P<f1>{FLAG})?\s*"
    rf"(?P<unit>{UNIT})?\s*(?P<range>{RANGE})?\s*(?P<f2>{FLAG})?$"
)
VALUE_ONLY = re.compile(rf"^(?P<value>{NUM})\s*(?:{FLAG})?$")
UNIT_ONLY = re.compile(rf"^{UNIT}$")
RANGE_ONLY = re.compile(rf"^{RANGE}$")
RANGE_PARTS = re.compile(rf"^(?P<lo>{NUM})\s*(?:-|–|—|to)\s*(?P<hi>{NUM})$")
RANGE_OP = re.compile(rf"^(?P<op><=|>=|<|>|≤|≥)\s*(?P<v>{NUM})$")

SKIP_WORDS = {"page", "age", "date", "phone", "mobile", "tel", "patient", "id", "sample", "collected",
              "reported", "registered", "received", "report", "dob", "year", "years", "ref", "no", "pin",
              "address", "lab", "doctor", "dr", "barcode", "sex", "gender", "time", "invoice", "bill",
              "result", "results", "test", "unit", "units", "range", "interval", "referred"}
FLAG_TOKENS = {"h", "l", "hh", "ll", "high", "low", "*"}


def _f(s):
    return float(s.replace(",", "."))


def _range(txt):
    if not txt:
        return None, None
    t = txt.strip()
    m = RANGE_PARTS.match(t)
    if m:
        return _f(m["lo"]), _f(m["hi"])
    m = RANGE_OP.match(t)
    if m:
        v = _f(m["v"])
        return (None, v) if m["op"] in ("<", "<=", "≤") else (v, None)
    return None, None


def _valid_name(name):
    name = re.sub(r"\s+", " ", name).strip(" .,-:")
    words = re.findall(r"[A-Za-z]+", name)
    if len(re.findall(r"[A-Za-z]", name)) < 2:
        return None
    if re.search(r"\s\d+(?:[.,]\d+)?$", name):
        return None  # a name ending in a bare number means the row was mis-split; drop rather than guess
    if words and words[0].lower() in SKIP_WORDS:
        return None
    if len(words) == 1 and words[0].lower() in SKIP_WORDS:
        return None
    return name


def _row(name, value, unit, rng):
    lo, hi = _range(rng)
    if unit:  # OCR often reads the caret in 10^3 as * or %
        unit = re.sub(r"^(/?(?:x\s?)?10)[*%](\d)", r"\1^\2", unit)
    return {
        "test_name": name, "value": value, "value_num": _f(value),
        "unit": unit or None, "reference_range": re.sub(r"\s+", " ", rng).strip() if rng else None,
        "ref_low": lo, "ref_high": hi,
    }


def _single_line(lines):
    rows = []
    for ln in lines:
        m = LINE_RE.match(ln)
        if not m:
            continue
        unit, rng = m["unit"], m["range"]
        if unit and unit.lower() in FLAG_TOKENS:
            unit = None
        if not unit and not rng:
            continue  # a bare "name number" is not enough evidence of a lab row
        name = _valid_name(m["name"])
        if name:
            rows.append(_row(name, m["value"], unit, rng))
    return rows


def _multi_line(lines):
    """Handles PDFs where every table cell is on its own line: name / value / unit / range."""
    rows, i = [], 0
    while i < len(lines) - 2:
        name = _valid_name(lines[i]) if not VALUE_ONLY.match(lines[i]) and not RANGE_ONLY.match(lines[i]) else None
        if name and VALUE_ONLY.match(lines[i + 1]):
            value = VALUE_ONLY.match(lines[i + 1])["value"]
            j, unit, rng = i + 2, None, None
            while j < len(lines) and j <= i + 4:
                t = lines[j]
                if t.lower() in FLAG_TOKENS:
                    j += 1; continue
                if rng is None and RANGE_ONLY.match(t):
                    rng = t; j += 1; continue
                if unit is None and rng is None and UNIT_ONLY.match(t) and not VALUE_ONLY.match(t) and len(t) <= 14:
                    unit = t; j += 1; continue
                break
            if unit or rng:
                rows.append(_row(name, value, unit, rng))
                i = j
                continue
        i += 1
    return rows


def parse_report(text: str):
    lines = [re.sub(r"[ \t]+", " ", l).strip() for l in text.splitlines()]
    lines = [l for l in lines if l]
    rows = _single_line(lines) + _multi_line(lines)
    seen, out = set(), []
    for r in rows:
        key = (r["test_name"].lower(), r["value"], r["unit"])
        if key not in seen:
            seen.add(key)
            out.append(r)
    return out
