"""PDF text extraction with PyMuPDF."""
import pymupdf


class ExtractionError(Exception):
    pass


def extract_text(path: str) -> str:
    try:
        with pymupdf.open(path) as doc:
            if doc.is_encrypted:
                raise ExtractionError("This PDF is password-protected.")
            return "\n".join(page.get_text("text") for page in doc).strip()
    except ExtractionError:
        raise
    except Exception as e:
        raise ExtractionError(f"The PDF could not be read ({type(e).__name__}). It may be corrupted.")


def render_pages_png(path: str, max_pages: int = 5, dpi: int = 200) -> list:
    """Render pages to PNG bytes so scanned PDFs can be sent through OCR."""
    out = []
    try:
        with pymupdf.open(path) as doc:
            for i, page in enumerate(doc):
                if i >= max_pages:
                    break
                out.append(page.get_pixmap(dpi=dpi).tobytes("png"))
    except Exception as e:
        raise ExtractionError(f"Could not render the PDF pages ({type(e).__name__}).")
    return out
