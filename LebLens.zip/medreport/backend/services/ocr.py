"""OCR service using Tesseract (optional). Install: apt install tesseract-ocr"""
import io
import shutil

try:
    import pytesseract
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover
    pytesseract = None


class OCRUnavailable(Exception):
    pass


def is_available() -> bool:
    return pytesseract is not None and shutil.which("tesseract") is not None


def ocr_image_bytes(data: bytes) -> str:
    if not is_available():
        raise OCRUnavailable("OCR is not available on the server (Tesseract is not installed).")
    try:
        img = Image.open(io.BytesIO(data))
        img = ImageOps.exif_transpose(img).convert("L")
        img = ImageOps.autocontrast(img)
        # psm 6: assume a uniform block of text - works well for lab tables
        return pytesseract.image_to_string(img, config="--psm 6").strip()
    except OCRUnavailable:
        raise
    except Exception as e:
        raise OCRUnavailable(f"OCR failed ({type(e).__name__}). The image may be unreadable.")
