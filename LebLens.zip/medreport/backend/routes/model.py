import json, os
from fastapi import APIRouter
from ml.model_loader import DIR

router = APIRouter(tags=["model"])


@router.get("/model/performance")
def performance():
    path = os.path.join(DIR, "metrics.json")
    if not os.path.exists(path):
        return {"trained": False, "message": "Model not trained yet"}
    with open(path) as fh:
        return json.load(fh)
