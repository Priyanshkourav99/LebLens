import os, uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from database import get_db
from models import User, Report, ExtractedResult, Prediction
from schemas import ReportSummary, ReportDetail, ResultOut
from security import current_user
from services import pdf_extractor, ocr
from services.report_parser import parse_report
from ml.predict import predict_report
from ml.explain import explain_report

router = APIRouter(tags=["reports"])
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "uploads")
MAX_BYTES = 10 * 1024 * 1024
ALLOWED = {".pdf": "pdf", ".jpg": "image", ".jpeg": "image", ".png": "image"}
MAGIC = {".pdf": [b"%PDF"], ".jpg": [b"\xff\xd8\xff"], ".jpeg": [b"\xff\xd8\xff"], ".png": [b"\x89PNG\r\n\x1a\n"]}
PENDING = "Pending ML Model"


def _own_report(db, user, rid) -> Report:
    r = db.query(Report).filter(Report.id == rid, Report.user_id == user.id).first()
    if not r:
        raise HTTPException(404, "Report not found.")
    return r


def _status_for(report, result):
    pred = next((p for p in report.predictions if p.result_id == result.id), None)
    if pred is None:
        return PENDING, None
    if pred.status == "OK" and pred.label:
        return pred.label, pred.confidence
    if pred.status == "NOT_APPLICABLE":
        return "Not assessed", None
    return PENDING, None


def _summary(report) -> dict:
    statuses = [_status_for(report, r)[0] for r in report.results]
    analyzed = any(s in ("Low", "Normal", "High") for s in statuses)
    return dict(id=report.id, filename=report.filename, file_type=report.file_type, created_at=report.created_at,
                result_count=len(report.results), flagged_count=sum(s in ("Low", "High") for s in statuses),
                analysis_status="Analyzed" if analyzed else PENDING)


@router.post("/upload-report", response_model=ReportDetail, status_code=201)
async def upload_report(file: UploadFile = File(...), db: Session = Depends(get_db),
                        user: User = Depends(current_user)):
    name = os.path.basename(file.filename or "")
    ext = os.path.splitext(name)[1].lower()
    if ext not in ALLOWED:
        raise HTTPException(400, "Unsupported file type. Upload a PDF, JPG or PNG file.")
    data = await file.read(MAX_BYTES + 1)
    if len(data) == 0:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File is too large. The maximum size is 10 MB.")
    if not any(data.startswith(m) for m in MAGIC[ext]):
        raise HTTPException(400, f"The file content does not match a valid {ext.upper().strip('.')} file.")

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4().hex}{ext}")
    with open(path, "wb") as fh:
        fh.write(data)

    def fail(code, msg):
        try: os.remove(path)
        except OSError: pass
        raise HTTPException(code, msg)

    # --- extraction ---
    method, text = "pdf_text", ""
    try:
        if ALLOWED[ext] == "pdf":
            text = pdf_extractor.extract_text(path)
            if len(text) < 20:  # likely a scanned PDF -> OCR the rendered pages
                method = "ocr"
                text = "\n".join(ocr.ocr_image_bytes(png) for png in pdf_extractor.render_pages_png(path))
        else:
            method = "ocr"
            text = ocr.ocr_image_bytes(data)
    except pdf_extractor.ExtractionError as e:
        fail(422, str(e))
    except ocr.OCRUnavailable as e:
        fail(422, f"Could not extract text from this file. {e}")
    if not text.strip():
        fail(422, "No readable text was found in this file. Upload a clearer or text-based report.")

    rows = parse_report(text)
    if not rows:
        fail(422, "No laboratory results were recognised. Check that the report lists test names, values and units/reference ranges.")

    # --- save + predict ---
    try:
        report = Report(user_id=user.id, filename=name[:255], stored_path=path, file_type=ALLOWED[ext],
                        extraction_method=method, raw_text=text)
        db.add(report)
        db.flush()
        results = [ExtractedResult(report_id=report.id, **r) for r in rows]
        db.add_all(results)
        db.flush()

        try:
            out = predict_report({"results": rows})
        except Exception as e:  # a broken model must never break uploads
            out = {"status": "ERROR", "message": f"Model error: {type(e).__name__}"}
        if out["status"] == "OK":
            for p in out["predictions"]:
                res = results[p["index"]]
                db.add(Prediction(report_id=report.id, result_id=res.id,
                                  status="OK" if p["label"] else "NOT_APPLICABLE", label=p["label"],
                                  confidence=p["confidence"], model_name=out["model_name"],
                                  message=None if p["label"] else "No reference range in report"))
        else:
            db.add(Prediction(report_id=report.id, status=out["status"], model_name=None,
                              message=out.get("message")))
        db.commit()
        db.refresh(report)
    except SQLAlchemyError:
        db.rollback()
        fail(500, "The report could not be saved. Please try again.")
    return _detail(report, include_text=True)


def _detail(report, include_text=False) -> dict:
    results = []
    for r in report.results:
        status, conf = _status_for(report, r)
        results.append(ResultOut(id=r.id, test_name=r.test_name, value=r.value, unit=r.unit,
                                 reference_range=r.reference_range, value_num=r.value_num,
                                 ref_low=r.ref_low, ref_high=r.ref_high, status=status, confidence=conf))
    try:
        exp = explain_report([dict(id=r.id, test_name=r.test_name, value=r.value, value_num=r.value_num, unit=r.unit,
                                   ref_low=r.ref_low, ref_high=r.ref_high, reference_range=r.reference_range,
                                   status=x.status) for r, x in zip(report.results, results)])
        for x in results:
            x.explanation = exp["items"].get(x.id)
        summary = exp["summary"]
    except Exception:  # explanations are a bonus; never break the report view
        summary = None
    report_level = next((p for p in report.predictions if p.result_id is None), None)
    ok = next((p for p in report.predictions if p.status == "OK"), None)
    return dict(**_summary(report), extraction_method=report.extraction_method,
                prediction_status=("OK" if ok else (report_level.status if report_level else "MODEL_NOT_CONNECTED")),
                prediction_message=(None if ok else (report_level.message if report_level else None)),
                model_name=ok.model_name if ok else None, results=results, summary=summary,
                raw_text=report.raw_text if include_text else None)


@router.get("/reports", response_model=list[ReportSummary])
def list_reports(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.query(Report).filter(Report.user_id == user.id).order_by(Report.created_at.desc(), Report.id.desc()).all()
    return [_summary(r) for r in rows]


@router.get("/reports/{rid}", response_model=ReportDetail)
def get_report(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return _detail(_own_report(db, user, rid), include_text=True)


@router.get("/reports/{rid}/results", response_model=list[ResultOut])
def get_results(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return _detail(_own_report(db, user, rid))["results"]


@router.delete("/reports/{rid}")
def delete_report(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    report = _own_report(db, user, rid)
    path = report.stored_path
    try:
        db.delete(report)
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        raise HTTPException(500, "The report could not be deleted. Please try again.")
    try: os.remove(path)
    except OSError: pass
    return {"message": "Report deleted."}
