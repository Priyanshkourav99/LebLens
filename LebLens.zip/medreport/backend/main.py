from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError
from database import Base, engine
import models  # noqa: F401  (registers tables)
from routes import auth, reports, model
from services import ocr

Base.metadata.create_all(bind=engine)
app = FastAPI(title="AI Medical Report Analyzer")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
for r in (auth.router, reports.router, model.router):
    app.include_router(r)


@app.exception_handler(RequestValidationError)
async def validation_handler(_: Request, exc: RequestValidationError):
    msg = "; ".join(str(e["msg"]).replace("Value error, ", "") for e in exc.errors())
    return JSONResponse(status_code=422, content={"detail": msg or "Invalid request."})


@app.exception_handler(SQLAlchemyError)
async def db_handler(_: Request, exc: SQLAlchemyError):
    return JSONResponse(status_code=500, content={"detail": "A database error occurred. Please try again."})


@app.get("/health")
def health():
    return {"status": "ok", "ocr_available": ocr.is_available()}
