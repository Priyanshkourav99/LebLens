import httpx, os, sys, uuid
B = "http://localhost:8000"; S = os.path.join(os.path.dirname(__file__), "samples")
c = httpx.Client(base_url=B, timeout=60)
ok = lambda cond, msg: (print(("PASS " if cond else "FAIL ") + msg), cond or sys.exit(1))
email = f"t{uuid.uuid4().hex[:6]}@example.com"

r = c.post("/register", json={"name": "Test User", "email": email, "password": "secret1"}); ok(r.status_code == 201, "register")
ok(c.post("/register", json={"name": "X Y", "email": email, "password": "secret1"}).status_code == 409, "duplicate email rejected")
ok(c.post("/register", json={"name": "X Y", "email": "bad", "password": "secret1"}).status_code == 422, "invalid email rejected")
ok(c.post("/login", json={"email": email, "password": "wrong"}).status_code == 401, "wrong password rejected")
r = c.post("/login", json={"email": email, "password": "secret1"}); ok(r.status_code == 200, "login")
H = {"Authorization": "Bearer " + r.json()["access_token"]}
ok(c.get("/reports").status_code == 401, "reports require auth")
ok(c.get("/reports", headers={"Authorization": "Bearer junk"}).status_code == 401, "bad token rejected")

def up(name, ctype="application/octet-stream"):
    with open(os.path.join(S, name), "rb") as f:
        return c.post("/upload-report", headers=H, files={"file": (name, f, ctype)})
ok(up("notes.txt").status_code == 400, "txt rejected")
ok(up("fake.pdf").status_code == 400, "fake pdf (bad magic bytes) rejected")
r = up("blank.pdf"); ok(r.status_code == 422, f"blank pdf rejected -> {r.json()['detail'][:60]}")
big = c.post("/upload-report", headers=H, files={"file": ("big.pdf", b"%PDF" + b"0" * (11 * 1024 * 1024))}); ok(big.status_code == 413, "oversize rejected")
ok(c.post("/upload-report", headers=H, files={"file": ("e.pdf", b"")}).status_code == 400, "empty file rejected")

r = up("lab_report.pdf"); ok(r.status_code == 201, "upload PDF"); rep = r.json()
print("  method:", rep["extraction_method"], "| rows:", len(rep["results"]), "| model:", rep["model_name"])
for x in rep["results"]: print("   ", x["test_name"], "|", x["value"], x["unit"], "|", x["reference_range"], "|", x["status"], x["confidence"])
exp = {"Hemoglobin": "Low", "WBC Count": "Normal", "Platelets": "High", "Fasting Glucose": "Normal",
       "Total Cholesterol": "High", "HDL Cholesterol": "Normal", "Creatinine": "Normal"}
got = {x["test_name"]: x["status"] for x in rep["results"]}
ok(all(got.get(k) == v for k, v in exp.items()), "all 7 extracted values + statuses correct (no invented rows: %d)" % len(got))
ok(len(got) == 7, "exactly 7 rows, nothing invented")
hb = next(x for x in rep["results"] if x["test_name"] == "Hemoglobin")["explanation"]
ok("anemia" in hb["meaning"] and "oxygen" in hb["what"] and "below" in hb["deviation"]["text"], "Hemoglobin explanation is specific (anemia / oxygen / deviation)")
ok("cholesterol" in " ".join(rep["summary"]["sections"][i]["group"] for i in range(len(rep["summary"]["sections"]))).lower(), "summary has cholesterol section")
ok(rep["summary"]["headline"].startswith("4 of 7"), "summary headline: " + rep["summary"]["headline"])
ok(len(rep["summary"]["next_steps"]) >= 2 and "diagnos" in rep["summary"]["disclaimer"], "next steps + disclaimer present")

r = up("lab_report.png", "image/png"); ok(r.status_code == 201, f"upload PNG via OCR -> {len(r.json().get('results', []))} rows")
png = r.json(); print("  OCR rows:", [(x['test_name'], x['value'], x['unit'], x['status']) for x in png["results"]])
ok({x["test_name"]: x["status"] for x in png["results"]} == exp, "OCR image gives the same 7 rows + statuses")

lst = c.get("/reports", headers=H).json(); ok(len(lst) == 2, "history lists 2 reports")
rid = rep["id"]
ok(c.get(f"/reports/{rid}", headers=H).json()["filename"] == "lab_report.pdf", "open report")
ok(len(c.get(f"/reports/{rid}/results", headers=H).json()) == 7, "GET results")
# isolation between users
e2 = f"u{uuid.uuid4().hex[:6]}@example.com"
H2 = {"Authorization": "Bearer " + c.post("/register", json={"name": "Other", "email": e2, "password": "secret1"}).json()["access_token"]}
ok(c.get(f"/reports/{rid}", headers=H2).status_code == 404, "other user cannot open my report")
ok(c.delete(f"/reports/{rid}", headers=H2).status_code == 404, "other user cannot delete my report")
ok(c.delete(f"/reports/{rid}", headers=H).status_code == 200, "delete report")
ok(c.get(f"/reports/{rid}", headers=H).status_code == 404, "deleted report gone")
ok(len(c.get("/reports", headers=H).json()) == 1, "history now 1")
ok(c.get("/model/performance").json()["trained"] is True, "model performance endpoint")
print("ALL BACKEND TESTS PASSED")
