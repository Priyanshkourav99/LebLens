import pymupdf, os
from PIL import Image, ImageDraw, ImageFont
out = os.path.join(os.path.dirname(__file__), "samples"); os.makedirs(out, exist_ok=True)
rows = [("Test Name", "Result", "Unit", "Reference Range"),
        ("Hemoglobin", "11.2", "g/dL", "13.0 - 17.0"), ("WBC Count", "7.4", "10^3/uL", "4.0 - 11.0"),
        ("Platelets", "430", "10^3/uL", "150 - 410"), ("Fasting Glucose", "92", "mg/dL", "70 - 100"),
        ("Total Cholesterol", "228", "mg/dL", "< 200"), ("HDL Cholesterol", "52", "mg/dL", "> 40"),
        ("Creatinine", "0.9", "mg/dL", "0.7 - 1.3")]
doc = pymupdf.open(); page = doc.new_page()
page.insert_text((50, 60), "CityCare Diagnostics - Complete Blood & Lipid Report", fontsize=14)
page.insert_text((50, 85), "Patient: Test User   Age: 34 Years   Page 1 of 1", fontsize=10)
y = 130
for r in rows:
    for x, cell in zip((50, 230, 320, 420), r):
        page.insert_text((x, y), cell, fontsize=11)
    y += 24
doc.save(os.path.join(out, "lab_report.pdf"))
blank = pymupdf.open(); blank.new_page(); blank.save(os.path.join(out, "blank.pdf"))
img = Image.new("RGB", (900, 420), "white"); d = ImageDraw.Draw(img)
f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 26)
y = 30
for r in rows:
    d.text((30, y), f"{r[0]}  {r[1]}  {r[2]}  {r[3]}" if r[0] != "Test Name" else "LABORATORY REPORT", fill="black", font=f); y += 48
img.save(os.path.join(out, "lab_report.png"))
open(os.path.join(out, "fake.pdf"), "wb").write(b"not a pdf at all")
open(os.path.join(out, "notes.txt"), "w").write("hello")
