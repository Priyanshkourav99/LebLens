"""Real-browser end-to-end test: Register -> Dashboard -> Upload PDF -> values -> History -> Delete -> Logout/Login."""
import os, uuid, sys
from playwright.sync_api import sync_playwright, expect
S = os.path.join(os.path.dirname(__file__), "samples"); URL = "http://127.0.0.1:5173"
email = f"ui{uuid.uuid4().hex[:6]}@example.com"
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1200, "height": 900})
    errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(URL); expect(pg.get_by_role("heading", name="Read your lab report in under a minute.")).to_be_visible(); print("PASS landing")
    pg.screenshot(path="/tmp/landing.png")
    pg.goto(URL + "/dashboard"); expect(pg.get_by_role("heading", name="Log in")).to_be_visible(); print("PASS dashboard protected")
    pg.goto(URL + "/register"); pg.fill("#name", "Asha Verma"); pg.fill("#email", email); pg.fill("#pw", "secret1")
    pg.get_by_role("button", name="Create account").click()
    expect(pg.get_by_text("Hello, Asha")).to_be_visible(); expect(pg.get_by_text("No reports yet").first).to_be_visible(); print("PASS register -> dashboard (empty state)")
    pg.get_by_role("link", name="Upload report").first.click()
    pg.set_input_files("input[type=file]", os.path.join(S, "notes.txt")); expect(pg.get_by_text("Unsupported file type")).to_be_visible(); print("PASS client rejects .txt")
    pg.set_input_files("input[type=file]", os.path.join(S, "lab_report.pdf"))
    pg.get_by_role("button", name="Upload and analyze").click()
    expect(pg.get_by_text("Report analyzed: 7 tests extracted.")).to_be_visible(timeout=20000)
    row = pg.get_by_role("row", name="Hemoglobin").first
    expect(row).to_contain_text("11.2"); expect(row).to_contain_text("g/dL"); expect(row).to_contain_text("13.0 - 17.0"); expect(row).to_contain_text("Low")
    expect(pg.get_by_role("row", name="Total Cholesterol").first).to_contain_text("High")
    expect(pg.get_by_text("Report summary", exact=False).first.or_(pg.get_by_label("Report summary"))).to_be_visible()
    expect(pg.get_by_text("4 of 7 results are within range")).to_be_visible()
    expect(pg.get_by_text("A low level is called anemia")).to_be_visible(); expect(pg.get_by_text("What this test measures").first).to_be_visible()
    pg.get_by_role("button", name="Hide explanation").first.click(); expect(pg.get_by_text("A low level is called anemia")).to_have_count(0)
    pg.get_by_role("button", name="What does this mean?").first.click(); expect(pg.get_by_text("A low level is called anemia")).to_be_visible()
    print("PASS upload PDF -> extracted values + summary + explanations displayed"); pg.screenshot(path="/tmp/report.png", full_page=True)
    pg.get_by_role("link", name="Dashboard").click()
    expect(pg.get_by_text("Latest analysis: lab_report.pdf")).to_be_visible(); expect(pg.locator(".stat b").first).to_have_text("1"); print("PASS dashboard shows report + latest analysis")
    pg.screenshot(path="/tmp/dashboard.png", full_page=True)
    pg.get_by_role("link", name="History").click(); expect(pg.get_by_role("row", name="lab_report.pdf")).to_be_visible(); print("PASS history lists report")
    pg.get_by_role("link", name="Open").click(); expect(pg.get_by_role("heading", name="lab_report.pdf")).to_be_visible(); print("PASS open previous report")
    pg.get_by_role("button", name="Delete report").click(); pg.get_by_role("button", name="Yes, delete").click()
    expect(pg.get_by_text("Report deleted.")).to_be_visible(); expect(pg.get_by_text("No reports yet").first).to_be_visible(); print("PASS delete report")
    pg.get_by_role("button", name="Log out").click(); expect(pg.get_by_role("link", name="Log in").first).to_be_visible(); print("PASS logout")
    pg.goto(URL + "/login"); pg.fill("#email", email); pg.fill("#pw", "nope123"); pg.get_by_role("button", name="Log in").last.click()
    expect(pg.get_by_text("Incorrect email or password.")).to_be_visible(); print("PASS bad login error shown")
    pg.fill("#pw", "secret1"); pg.get_by_role("button", name="Log in").last.click(); expect(pg.get_by_text("Hello, Asha")).to_be_visible(); print("PASS login")
    pg.goto(URL + "/model"); expect(pg.get_by_text("Confusion matrix")).to_be_visible(); pg.screenshot(path="/tmp/model.png", full_page=True); print("PASS model performance page")
    assert not errs, errs
    b.close()
print("ALL UI TESTS PASSED")
