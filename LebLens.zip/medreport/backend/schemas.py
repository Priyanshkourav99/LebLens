import re
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, field_validator

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class RegisterIn(BaseModel):
    name: str
    email: str
    password: str

    @field_validator("name")
    @classmethod
    def _name(cls, v):
        v = v.strip()
        if len(v) < 2:
            raise ValueError("Name must be at least 2 characters")
        return v

    @field_validator("email")
    @classmethod
    def _email(cls, v):
        v = v.strip().lower()
        if not EMAIL_RE.match(v):
            raise ValueError("Enter a valid email address")
        return v

    @field_validator("password")
    @classmethod
    def _pw(cls, v):
        if len(v) < 6:
            raise ValueError("Password must be at least 6 characters")
        return v


class LoginIn(BaseModel):
    email: str
    password: str


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    model_config = {"from_attributes": True}


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class ResultOut(BaseModel):
    id: int
    test_name: str
    value: str
    unit: Optional[str] = None
    reference_range: Optional[str] = None
    value_num: Optional[float] = None
    ref_low: Optional[float] = None
    ref_high: Optional[float] = None
    status: str                       # Low / Normal / High / Pending ML Model / Not assessed
    confidence: Optional[float] = None
    explanation: Optional[dict] = None


class ReportSummary(BaseModel):
    id: int
    filename: str
    file_type: str
    created_at: datetime
    result_count: int
    flagged_count: int
    analysis_status: str              # Analyzed | Pending ML Model


class ReportDetail(ReportSummary):
    extraction_method: Optional[str] = None
    prediction_status: str
    prediction_message: Optional[str] = None
    model_name: Optional[str] = None
    results: List[ResultOut]
    summary: Optional[dict] = None
    raw_text: Optional[str] = None
