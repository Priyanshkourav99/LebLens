"""Generates a SYNTHETIC dataset and trains a Low/Normal/High classifier.

Run:  python -m ml.train        (from the backend/ folder)

IMPORTANT: the data is synthetic. Values are sampled around typical adult reference ranges and
labelled by comparing against the range. The model therefore learns range-comparison logic, NOT
clinical diagnosis. Metrics describe performance on this synthetic data only.
To use your own data: replace `make_dataset()` with a loader that returns X, y (labels in LABELS).
"""
import json, os, time
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from ml.features import build_features, FEATURE_NAMES

LABELS = ["Low", "Normal", "High"]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "saved_models")

# (test, low, high) - typical adult reference ranges. low/high None => one-sided range.
CATALOG = [
    ("Hemoglobin", 13.0, 17.0), ("Hemoglobin (F)", 12.0, 15.5), ("RBC Count", 4.5, 5.9), ("WBC Count", 4.0, 11.0),
    ("Platelets", 150, 410), ("Hematocrit", 38, 50), ("MCV", 80, 100), ("MCH", 27, 33), ("MCHC", 32, 36),
    ("Neutrophils", 40, 75), ("Lymphocytes", 20, 45), ("Fasting Glucose", 70, 100), ("HbA1c", None, 5.7),
    ("Total Cholesterol", None, 200), ("LDL Cholesterol", None, 100), ("HDL Cholesterol", 40, None),
    ("Triglycerides", None, 150), ("Creatinine", 0.7, 1.3), ("Urea", 15, 40), ("Uric Acid", 3.5, 7.2),
    ("ALT (SGPT)", 7, 56), ("AST (SGOT)", 10, 40), ("ALP", 44, 147), ("Total Bilirubin", 0.1, 1.2),
    ("Total Protein", 6.0, 8.3), ("Albumin", 3.5, 5.0), ("Sodium", 135, 145), ("Potassium", 3.5, 5.1),
    ("Calcium", 8.6, 10.2), ("TSH", 0.4, 4.0), ("Vitamin D", 30, 100), ("Vitamin B12", 200, 900),
    ("Ferritin", 30, 400), ("Iron", 60, 170), ("CRP", None, 5.0),
]


def make_dataset(n=12000, seed=42):
    rng = np.random.default_rng(seed)
    X, y = [], []
    for _ in range(n):
        _, lo, hi = CATALOG[rng.integers(len(CATALOG))]
        # jitter the printed range slightly: different labs publish slightly different ranges
        k = rng.uniform(0.9, 1.1)
        lo = None if lo is None else round(lo * k, 2)
        hi = None if hi is None else round(hi * k, 2)
        ref_lo = lo if lo is not None else 0.0
        ref_hi = hi if hi is not None else (lo * 1.6)
        span = ref_hi - ref_lo
        mode = rng.choice(["low", "normal", "high"], p=[0.25, 0.45, 0.30])
        if mode == "low":
            v = ref_lo - abs(rng.normal(0, 0.35)) * span if lo is not None else ref_lo + rng.uniform(0, 0.02) * span
        elif mode == "high":
            v = ref_hi + abs(rng.normal(0, 0.45)) * span if hi is not None else ref_hi + rng.uniform(0, 0.5) * span
        else:
            v = rng.uniform(ref_lo, ref_hi)
        v = round(max(v, 0.01), 2)
        label = "Low" if (lo is not None and v < lo) else "High" if (hi is not None and v > hi) else "Normal"
        X.append(build_features(v, lo, hi)); y.append(LABELS.index(label))
    return np.array(X), np.array(y)


def main():
    t0 = time.time()
    X, y = make_dataset()
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    candidates = {
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
        "Random Forest": RandomForestClassifier(n_estimators=150, random_state=42, n_jobs=-1),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42),
    }
    comparison, fitted = [], {}
    for name, model in candidates.items():
        model.fit(Xtr, ytr)
        pred = model.predict(Xte)
        p, r, f, _ = precision_recall_fscore_support(yte, pred, average="macro", zero_division=0)
        comparison.append({"model": name, "accuracy": round(accuracy_score(yte, pred), 4),
                           "precision": round(p, 4), "recall": round(r, 4), "f1": round(f, 4)})
        fitted[name] = model
    best = max(comparison, key=lambda c: (c["f1"], c["accuracy"]))["model"]
    pred = fitted[best].predict(Xte)
    cm = confusion_matrix(yte, pred, labels=[0, 1, 2]).tolist()
    best_row = next(c for c in comparison if c["model"] == best)

    os.makedirs(OUT, exist_ok=True)
    joblib.dump({"model": fitted[best], "labels": LABELS, "features": FEATURE_NAMES, "name": best},
                os.path.join(OUT, "my_model.joblib"))
    metrics = {
        "trained": True, "model_name": best, "labels": LABELS,
        "accuracy": best_row["accuracy"], "precision": best_row["precision"],
        "recall": best_row["recall"], "f1": best_row["f1"], "averaging": "macro",
        "confusion_matrix": cm, "comparison": comparison,
        "train_size": int(len(ytr)), "test_size": int(len(yte)),
        "class_counts_test": {LABELS[i]: int((yte == i).sum()) for i in range(3)},
        "data_source": "synthetic",
        "note": "Trained and evaluated on a synthetic dataset generated from typical reference ranges. "
                "These numbers show the model reproduces range-comparison logic; they are not clinical validation.",
        "trained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(os.path.join(OUT, "metrics.json"), "w") as fh:
        json.dump(metrics, fh, indent=2)
    print(f"Best model: {best}  acc={best_row['accuracy']}  f1={best_row['f1']}  ({time.time()-t0:.1f}s)")
    for c in comparison:
        print(c)
    print("Confusion matrix (rows=true, cols=pred, order Low/Normal/High):", cm)


if __name__ == "__main__":
    main()
