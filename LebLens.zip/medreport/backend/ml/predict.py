"""Single integration point between the app and the ML model.

predict_report(data) receives {"results": [ {test_name, value_num, ref_low, ref_high, ...}, ... ]}
and returns either
  {"status": "MODEL_NOT_CONNECTED", "message": "..."}                      (no model file present)
or
  {"status": "OK", "model_name": str, "predictions": [{"index": i, "label": str|None, "confidence": float|None}]}

To swap in your own model: replace saved_models/my_model.joblib, and adapt build_features() in
ml/features.py if your model expects different inputs. Nothing else in the app has to change.
"""
from ml.model_loader import load_model
from ml.features import build_features


def predict_report(data):
    bundle = load_model()
    if bundle is None:
        return {"status": "MODEL_NOT_CONNECTED", "message": "The trained ML model will be connected here."}

    results = data.get("results", [])
    idx, feats = [], []
    for i, r in enumerate(results):
        if r.get("value_num") is None or (r.get("ref_low") is None and r.get("ref_high") is None):
            continue  # no reference range printed in the report -> nothing to assess, we don't guess
        idx.append(i)
        feats.append(build_features(r["value_num"], r.get("ref_low"), r.get("ref_high")))

    preds = [{"index": i, "label": None, "confidence": None} for i in range(len(results))]
    if feats:
        import numpy as np
        model, labels = bundle["model"], bundle["labels"]
        X = np.vstack(feats)
        out = model.predict(X)
        proba = model.predict_proba(X).max(axis=1) if hasattr(model, "predict_proba") else [None] * len(out)
        for i, o, p in zip(idx, out, proba):
            preds[i] = {"index": i, "label": labels[int(o)] if not isinstance(o, str) else o,
                        "confidence": None if p is None else round(float(p), 3)}
    return {"status": "OK", "model_name": bundle.get("name", "model"), "predictions": preds}
