"""Loads the trained model once. To use your own model, drop it in saved_models/ as my_model.joblib
(or .pkl) - a dict {"model": estimator, "labels": [...], "name": "..."} or a bare sklearn estimator."""
import os
import joblib

DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "saved_models")
CANDIDATES = ["my_model.joblib", "my_model.pkl"]
_cache = {"bundle": None, "loaded": False}


def load_model(force=False):
    if _cache["loaded"] and not force:
        return _cache["bundle"]
    _cache.update(bundle=None, loaded=True)
    for fn in CANDIDATES:
        path = os.path.join(DIR, fn)
        if os.path.exists(path):
            obj = joblib.load(path)
            if not isinstance(obj, dict):
                obj = {"model": obj, "labels": ["Low", "Normal", "High"], "name": type(obj).__name__}
            _cache["bundle"] = obj
            break
    return _cache["bundle"]
