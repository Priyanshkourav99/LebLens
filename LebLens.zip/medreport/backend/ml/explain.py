"""Turns Low/Normal/High labels into plain-language context for each result and for the whole report.

explain_report(results) -> {"items": {result_id: {...}}, "summary": {...}}
Input rows need: id, test_name, value, value_num, unit, ref_low, ref_high, reference_range, status.
`status` comes from predict_report (your trained model); this layer only adds meaning on top of it.
It is rule-based and educational. It never diagnoses, and it only states facts about values present in the report."""
import re
from ml.knowledge import KB, ALIASES, GROUP_ORDER

DISCLAIMER = ("This is general educational information based on the values in your report. It is not a diagnosis. "
              "Only a qualified healthcare professional can interpret results in light of your symptoms and history.")


def match_test(name):
    n = re.sub(r"\s+", " ", name.lower()).strip()
    for pat, key in ALIASES:
        if re.search(pat, n):
            return key
    return None


def _fmt(v):
    return f"{v:g}"


def _deviation(r, status):
    v, lo, hi = r.get("value_num"), r.get("ref_low"), r.get("ref_high")
    if v is None or status not in ("Low", "High"):
        return None
    bound = lo if status == "Low" else hi
    if bound is None:
        return None
    span = (hi - lo) if (lo is not None and hi is not None and hi > lo) else (abs(bound) * 2) or 1  # one-sided range: be less alarmist
    diff = abs(v - bound)
    ratio = diff / span
    level = "slightly" if ratio < 0.1 else "moderately" if ratio < 0.5 else "markedly"
    side = "below the lower" if status == "Low" else "above the upper"
    pct = f" (about {diff / abs(bound) * 100:.0f}% {'under' if status == 'Low' else 'over'})" if bound else ""
    return {"level": level, "text": f"{_fmt(v)} is {level} {side} limit of {_fmt(bound)}{pct}."}


def _item(r, key):
    status = r["status"]
    entry = KB.get(key)
    out = {"what": entry["what"] if entry else None, "meaning": None, "deviation": _deviation(r, status),
           "known": entry is not None, "group": entry["group"] if entry else "Other tests"}
    name = entry["name"] if entry else r["test_name"]
    if status == "Low":
        out["meaning"] = entry["low"] if entry else f"{name} is below the range printed in your report. This tool has no specific notes for this test, so ask your doctor what it means for you."
    elif status == "High":
        out["meaning"] = entry["high"] if entry else f"{name} is above the range printed in your report. This tool has no specific notes for this test, so ask your doctor what it means for you."
    elif status == "Normal":
        out["meaning"] = "This value is inside the reference range printed in your report, so nothing stands out for this test on its own."
    elif status == "Not assessed":
        out["meaning"] = "This result could not be compared because the report does not print a reference range for it."
    else:
        out["meaning"] = "No model is connected yet, so this result has not been assessed."
    return out


PATTERNS = [
    (lambda s: s.get("hemoglobin") == "Low" or (s.get("rbc") == "Low" and s.get("hematocrit") == "Low"),
     lambda s: "Low hemoglobin with " + (
         "small red cells (low MCV) is a pattern often seen with iron deficiency or thalassemia trait; ferritin and iron tests help tell them apart." if s.get("mcv") == "Low" else
         "larger red cells (high MCV) is a pattern often seen with vitamin B12 or folate shortage, alcohol use or thyroid or liver conditions." if s.get("mcv") == "High" else
         "normal-sized red cells has several possible causes, including long-term illness or recent blood loss. Iron, B12 and ferritin tests are common next steps.")
     + (" Your low ferritin supports iron deficiency." if s.get("ferritin") == "Low" else "")),
    (lambda s: sum(s.get(k) == "High" for k in ("total_chol", "ldl", "triglycerides")) >= 2 or (s.get("hdl") == "Low" and any(s.get(k) == "High" for k in ("total_chol", "ldl", "triglycerides"))),
     lambda s: "Several cholesterol and blood-fat values are outside range together. This combination raises long-term heart and blood-vessel risk, and it often responds well to diet, activity and weight changes; your doctor can discuss whether treatment is needed."),
    (lambda s: s.get("glucose") == "High" or s.get("hba1c") == "High",
     lambda s: ("Both fasting glucose and HbA1c are high, which together make a stronger signal of raised blood sugar. " if s.get("glucose") == "High" and s.get("hba1c") == "High" else "Your blood-sugar measure is above range. ") + "A doctor will usually repeat the test and decide whether this is prediabetes or diabetes."),
    (lambda s: any(s.get(k) == "High" for k in ("alt", "ast", "alp", "bilirubin")),
     lambda s: "One or more liver markers are raised. ALT and AST rising together usually point to irritated liver cells; fatty liver, alcohol, medicines and viral hepatitis are the usual things doctors consider."),
    (lambda s: s.get("creatinine") == "High" or (s.get("urea") == "High" and s.get("creatinine") != "Normal"),
     lambda s: "Kidney-related markers are raised" + (" together" if s.get("creatinine") == "High" and s.get("urea") == "High" else "") + ". Dehydration is a common and reversible cause, so doctors often repeat the test after good hydration."),
    (lambda s: s.get("wbc") == "High" or s.get("neutrophils") == "High" or s.get("crp") == "High",
     lambda s: "Markers of infection or inflammation are raised. This is a common, usually temporary response to infection, but it does not show where the cause is."),
    (lambda s: s.get("wbc") == "Low",
     lambda s: "A low white cell count is often temporary after a viral illness, but it is worth repeating and discussing, especially if you get infections often."),
    (lambda s: s.get("tsh") in ("High", "Low"),
     lambda s: "TSH is " + ("high, which points toward an underactive thyroid." if s.get("tsh") == "High" else "low, which points toward an overactive thyroid or too much thyroid medication.") + " Free T3/T4 are usually checked to confirm."),
    (lambda s: any(s.get(k) == "Low" for k in ("vit_d", "b12", "ferritin", "iron")) and s.get("hemoglobin") != "Low",
     lambda s: "Some vitamin or iron stores are low. These are common and usually corrected with diet or supplements, ideally guided by your doctor."),
]


def explain_report(results):
    items, groups, status_by_key = {}, {}, {}
    for r in results:
        key = match_test(r["test_name"])
        items[r["id"]] = _item(r, key)
        if key and r["status"] in ("Low", "High", "Normal"):
            status_by_key.setdefault(key, r["status"])
        g = KB[key]["group"] if key else "Other tests"
        groups.setdefault(g, []).append((key, r))

    assessed = [r for r in results if r["status"] in ("Low", "Normal", "High")]
    flagged = [r for r in assessed if r["status"] != "Normal"]
    if not assessed:
        return {"items": items, "summary": None}

    if flagged:
        headline = f"{len(assessed) - len(flagged)} of {len(assessed)} results are within range; {len(flagged)} {'is' if len(flagged) == 1 else 'are'} outside it."
    else:
        headline = f"All {len(assessed)} results with a printed reference range are within range."

    sections = []
    for g in GROUP_ORDER:
        rows = groups.get(g)
        if not rows:
            continue
        rows_a = [(k, r) for k, r in rows if r["status"] in ("Low", "Normal", "High")]
        if not rows_a:
            continue
        bad = [(k, r) for k, r in rows_a if r["status"] != "Normal"]
        if not bad:
            sections.append({"group": g, "tone": "ok", "text": "All values are within range."})
        else:
            parts = []
            for k, r in bad:
                nm = KB[k]["name"] if k else r["test_name"]
                d = items[r["id"]]["deviation"]
                parts.append(f"{nm} is {r['status'].lower()} at {r['value']}{(' ' + r['unit']) if r.get('unit') else ''}" + (f" ({d['level']} {'under' if r['status'] == 'Low' else 'over'} range)" if d else ""))
            ok_n = len(rows_a) - len(bad)
            sections.append({"group": g, "tone": "flag", "text": "; ".join(parts) + "." + (f" The other {ok_n} {'is' if ok_n == 1 else 'are'} within range." if ok_n else "")})

    patterns = [fn(status_by_key) for cond, fn in PATTERNS if cond(status_by_key)]
    markedly = [r["test_name"] for r in flagged if (items[r["id"]]["deviation"] or {}).get("level") == "markedly"]
    next_steps = []
    if flagged:
        next_steps.append("Share this report with your doctor. A single result outside range is often not serious and is sometimes repeated to confirm.")
        if markedly:
            next_steps.append("Values far outside range (" + ", ".join(markedly[:4]) + ") deserve a prompt conversation with a doctor rather than waiting for the next routine visit.")
        next_steps.append("Do not start, stop or change any medicine because of this report without medical advice.")
    else:
        next_steps.append("Nothing in this report is outside the printed ranges. Keep up regular check-ups as your doctor recommends.")
    skipped = len(results) - len(assessed)
    if skipped:
        next_steps.append(f"{skipped} test(s) could not be compared because no reference range was printed.")
    return {"items": items, "summary": {"headline": headline, "sections": sections, "patterns": patterns,
                                        "next_steps": next_steps, "disclaimer": DISCLAIMER}}
