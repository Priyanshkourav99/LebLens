"""Shared feature engineering (used by training AND inference so they never drift apart)."""
import numpy as np

FEATURE_NAMES = ["has_low", "has_high", "pos_in_range", "ratio_to_low", "ratio_to_high", "dist_low", "dist_high"]


def build_features(value, low, high):
    """value: float; low/high: float or None. Returns a 1-D feature vector."""
    has_low, has_high = low is not None, high is not None
    span = (high - low) if (has_low and has_high and high > low) else None
    pos = (value - low) / span if span else 0.5
    r_low = value / low if has_low and low > 0 else 1.0
    r_high = value / high if has_high and high > 0 else 1.0
    scale = span if span else (abs(high) if has_high and high else (abs(low) if has_low and low else 1.0))
    d_low = (value - low) / scale if has_low else 0.0
    d_high = (value - high) / scale if has_high else 0.0
    return np.array([has_low, has_high, pos, r_low, r_high, d_low, d_high], dtype=float)
