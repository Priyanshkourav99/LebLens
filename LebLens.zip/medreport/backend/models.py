from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    reports = relationship("Report", back_populates="user", cascade="all, delete-orphan")


class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    filename = Column(String(255), nullable=False)
    stored_path = Column(String(500), nullable=False)
    file_type = Column(String(20), nullable=False)
    extraction_method = Column(String(30))  # pdf_text | ocr
    raw_text = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="reports")
    results = relationship("ExtractedResult", back_populates="report", cascade="all, delete-orphan",
                           order_by="ExtractedResult.id")
    predictions = relationship("Prediction", back_populates="report", cascade="all, delete-orphan")


class ExtractedResult(Base):
    __tablename__ = "extracted_results"
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey("reports.id", ondelete="CASCADE"), index=True, nullable=False)
    test_name = Column(String(200), nullable=False)
    value = Column(String(50), nullable=False)       # as printed in the report
    value_num = Column(Float)
    unit = Column(String(50))
    reference_range = Column(String(100))            # as printed in the report
    ref_low = Column(Float)
    ref_high = Column(Float)
    report = relationship("Report", back_populates="results")


class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey("reports.id", ondelete="CASCADE"), index=True, nullable=False)
    result_id = Column(Integer, ForeignKey("extracted_results.id", ondelete="CASCADE"), nullable=True)
    status = Column(String(30), nullable=False)      # OK | MODEL_NOT_CONNECTED | NOT_APPLICABLE | ERROR
    label = Column(String(30))
    confidence = Column(Float)
    model_name = Column(String(100))
    message = Column(String(300))
    created_at = Column(DateTime, default=datetime.utcnow)
    report = relationship("Report", back_populates="predictions")
