# LabLens – AI-based medical report analyzer (academic project)

React + FastAPI + SQLite. Upload a lab report (PDF/JPG/PNG) → text extracted (PyMuPDF / Tesseract OCR) →
rule-based parser finds test / value / unit / reference range → ML model labels each result Low / Normal / High.

## Run
```bash
# backend  (Python 3.10+; for image OCR also: sudo apt install tesseract-ocr)
cd backend
pip install -r requirements.txt
python -m ml.train            # (re)creates the synthetic dataset + model + metrics.json
uvicorn main:app --port 8000

# frontend (new terminal)
cd frontend
npm install
npm run dev                   # http://localhost:5173  (proxies /api -> :8000)
```
Set `SECRET_KEY` (env var) before any real deployment.

## Tests (servers running)
```bash
python backend/tests/make_samples.py
python backend/tests/test_flow.py     # API: auth, validation, upload, history, delete, user isolation
python backend/tests/test_ui.py       # browser flow (needs: pip install playwright && playwright install chromium)
```

## Explanations ("what does this result mean?")
`ml/explain.py` + `ml/knowledge.py` add plain-language context on top of the model's Low/Normal/High labels:
what each test measures, what a low/high value can be associated with, how far outside the range it is,
cross-test patterns (e.g. low Hb + low MCV + low ferritin) and general next steps. It is a rule-based knowledge
base (no external AI), so it keeps working when you swap in your own model: it only needs the label.
To cover more tests, add an entry to `KB` and an alias to `ALIASES` in `ml/knowledge.py`.
Tests not in the knowledge base get an honest "no specific notes" message instead of a guess.

## Replace the model with your own
1. Train on your data and save with joblib to `backend/ml/saved_models/my_model.joblib` (or `.pkl`):
   either a bare sklearn estimator, or `{"model": est, "labels": ["Low","Normal","High"], "name": "My model"}`.
2. If your model expects other inputs, edit `build_features()` in `ml/features.py` (used for training and inference).
3. Overwrite `saved_models/metrics.json` with your real metrics (same keys) and the Model performance page updates.
4. If no model file exists, `predict_report()` returns `{"status": "MODEL_NOT_CONNECTED", ...}` and the UI shows "Pending ML Model".

## Important: the bundled model
It is trained on a **synthetic** dataset (values sampled around typical reference ranges, labelled by comparing to the range).
It reproduces range-comparison logic, so its ~100% scores are expected and are NOT clinical validation.

*This application is an educational tool and does not provide medical diagnosis or replace a qualified healthcare professional.*
